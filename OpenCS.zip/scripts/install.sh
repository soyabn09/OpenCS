#!/bin/bash
clear