#!/bin/bash
clear

