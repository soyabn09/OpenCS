# OpenCS
OpenCS is a complete, open source and free billing solution that intergrates with existing software like Pterodactyl, Multicraft, cPanel, VestaCP, ISPConfig and many more. With help from the community many more intergrations will be supported over time with 3d party plugins.

Copyright (C) 2020 [RASCRY Foundation Limited P.T.C.](https://bhk.arctischia.eu/look.php?cname=&cid=329c5cca-8127-4577-99a6-23dc2eb20389)
